import tkinter as tk
from tkinter import messagebox, ttk, simpledialog
import socket
import threading
import time
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import os
import getpass
import sys
import datetime
import json
import logging

# Configurazione del logging
logging.basicConfig(filename='chat.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

class ChatApp:
    def __init__(self):
        self.use_gui = input("Usare interfaccia grafica? (s/n): ").strip().lower() == 's'
        self.username = None
        self.password = None
        self.private_key = None
        self.public_key = None
        self.connected_users = {}  # {username: (public_key, ip, timestamp, status)}
        self.chat_sessions = {}    # {username: ChatSession}
        self.rooms = {}            # {room_name: set(usernames)}
        self.message_history = self.load_message_history()
        self.server_host = 'localhost'  # Host del server dedicato
        self.server_port = 5002        # Porta del server dedicato
        if self.use_gui:
            self.init_gui_login()
        else:
            self.init_cli_login()

    def load_message_history(self):
        """Carica la cronologia dei messaggi da file."""
        try:
            with open('message_history.json', 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def save_message_history(self):
        """Salva la cronologia dei messaggi su file."""
        with open('message_history.json', 'w') as f:
            json.dump(self.message_history, f, indent=2)

    def init_gui_login(self):
        """Inizializza l'interfaccia grafica per il login."""
        self.window = tk.Tk()
        self.window.title("Login - Secure Chat")
        self.window.geometry("300x200")
        tk.Label(self.window, text="Username:").pack(pady=5)
        self.username_entry = tk.Entry(self.window)
        self.username_entry.pack(pady=5)
        tk.Label(self.window, text="Password:").pack(pady=5)
        self.password_entry = tk.Entry(self.window, show="*")
        self.password_entry.pack(pady=5)
        tk.Button(self.window, text="Login", command=self.login).pack(pady=10)
        self.window.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.window.mainloop()

    def init_cli_login(self):
        """Inizializza il login da riga di comando."""
        print("--- Login ---")
        self.username = input("Username: ").strip()
        self.password = getpass.getpass("Password: ").strip()
        self.login()

    def login(self):
        """Gestisce il processo di login."""
        if self.use_gui:
            self.username = self.username_entry.get().strip()
            self.password = self.password_entry.get().strip()
            if not self.username or not self.password:
                messagebox.showerror("Errore", "Username e password richiesti")
                return
        else:
            if not self.username or not self.password:
                print("Username e password richiesti")
                sys.exit(1)

        key_file = f"{self.username}_private_key.pem"
        if os.path.exists(key_file):
            with open(key_file, "rb") as f:
                encrypted_key = f.read()
            salt = encrypted_key[:16]
            kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100000)
            key = kdf.derive(self.password.encode())
            cipher = Cipher(algorithms.AES(key), modes.CFB(encrypted_key[16:32]))
            decryptor = cipher.decryptor()
            private_key_pem = decryptor.update(encrypted_key[32:]) + decryptor.finalize()
            try:
                self.private_key = serialization.load_pem_private_key(private_key_pem, None)
            except:
                if self.use_gui:
                    messagebox.showerror("Errore", "Password errata")
                else:
                    print("Password errata")
                return
        else:
            self.private_key = ec.generate_private_key(ec.SECP256R1())
            private_key_pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            salt = os.urandom(16)
            kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100000)
            key = kdf.derive(self.password.encode())
            iv = os.urandom(16)
            cipher = Cipher(algorithms.AES(key), modes.CFB(iv))
            encryptor = cipher.encryptor()
            encrypted_key = encryptor.update(private_key_pem) + encryptor.finalize()
            with open(key_file, "wb") as f:
                f.write(salt + iv + encrypted_key)

        self.public_key = self.private_key.public_key()
        logging.info(f"Utente {self.username} loggato con successo")

        self.start_background_threads()
        if self.use_gui:
            self.window.withdraw()
            self.setup_gui_main()
        else:
            self.cli_main_loop()

    def start_background_threads(self):
        """Avvia i thread in background per la gestione della rete."""
        self.broadcast_thread = threading.Thread(target=self.broadcast_presence)
        self.broadcast_thread.daemon = True
        self.broadcast_thread.start()

        self.udp_listener_thread = threading.Thread(target=self.udp_listener)
        self.udp_listener_thread.daemon = True
        self.udp_listener_thread.start()

        self.tcp_listener_thread = threading.Thread(target=self.tcp_listener)
        self.tcp_listener_thread.daemon = True
        self.tcp_listener_thread.start()

        self.cleanup_thread = threading.Thread(target=self.cleanup_users)
        self.cleanup_thread.daemon = True
        self.cleanup_thread.start()

    def setup_gui_main(self):
        """Imposta l'interfaccia grafica principale."""
        self.main_window = tk.Toplevel()
        self.main_window.title(f"Secure Chat - {self.username}")
        self.main_window.geometry("800x500")

        self.left_frame = tk.Frame(self.main_window)
        self.left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)

        tk.Label(self.left_frame, text="Utenti").pack()
        self.users_listbox = tk.Listbox(self.left_frame, width=25, height=15)
        self.users_listbox.pack(fill=tk.Y)
        self.users_listbox.bind('<Double-Button-1>', self.start_chat)

        tk.Label(self.left_frame, text="Stanze").pack()
        self.rooms_listbox = tk.Listbox(self.left_frame, width=25, height=5)
        self.rooms_listbox.pack(fill=tk.Y)
        self.rooms_listbox.bind('<Double-Button-1>', self.join_room_gui)
        tk.Button(self.left_frame, text="Crea Stanza", command=self.create_room_gui).pack(pady=5)

        self.notebook = ttk.Notebook(self.main_window)
        self.notebook.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.chat_tabs = {}

        self.main_window.protocol("WM_DELETE_WINDOW", self.on_closing)

    def broadcast_presence(self):
        """Trasmette la presenza dell'utente sulla rete."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while True:
            public_key_der = self.public_key.public_bytes(
                encoding=serialization.Encoding.DER,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
            msg = f"{self.username}:{base64.b64encode(public_key_der).decode()}"
            sock.sendto(msg.encode(), ('255.255.255.255', 5000))
            time.sleep(2)

    def udp_listener(self):
        """Ascolta i messaggi UDP per scoprire altri utenti."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', 5000))
        while True:
            data, addr = sock.recvfrom(1024)
            try:
                msg = data.decode()
                username, pub_key_b64 = msg.split(':', 1)
                if username == self.username:
                    continue
                pub_key_der = base64.b64decode(pub_key_b64)
                public_key = serialization.load_der_public_key(pub_key_der)
                self.connected_users[username] = (public_key, addr[0], time.time(), "online")
                if self.use_gui:
                    self.update_users_listbox()
            except Exception as e:
                logging.error(f"Errore UDP listener: {e}")

    def update_users_listbox(self):
        """Aggiorna la lista degli utenti nell'interfaccia grafica."""
        self.users_listbox.delete(0, tk.END)
        for username in sorted(self.connected_users.keys()):
            status = self.connected_users[username][3]
            self.users_listbox.insert(tk.END, f"{username} ({status})")

    def cleanup_users(self):
        """Rimuove gli utenti inattivi."""
        while True:
            time.sleep(5)
            current_time = time.time()
            to_remove = []
            for u, (_, _, t, status) in self.connected_users.items():
                if current_time - t > 10:
                    if status == "online":
                        self.connected_users[u] = (self.connected_users[u][0], self.connected_users[u][1], t, "offline")
                    else:
                        to_remove.append(u)
            for u in to_remove:
                del self.connected_users[u]
            if self.use_gui:
                self.update_users_listbox()

    def tcp_listener(self):
        """Ascolta le connessioni TCP per le chat private."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', 5001))
        sock.listen(5)
        while True:
            conn, _ = sock.accept()
            threading.Thread(target=self.handle_incoming_connection, args=(conn,), daemon=True).start()

    def handle_incoming_connection(self, conn):
        """Gestisce una connessione TCP in entrata per chat private."""
        try:
            username = conn.recv(1024).decode().strip()
            if username not in self.connected_users:
                conn.close()
                return
            public_key = self.connected_users[username][0]
            shared_secret = self.private_key.exchange(ec.ECDH(), public_key)
            digest = hashes.Hash(hashes.SHA256())
            digest.update(shared_secret)
            aes_key = digest.finalize()
            chat_session = ChatSession(conn, aes_key, username, self)
            self.chat_sessions[username] = chat_session
            chat_session.start_listener()
        except Exception as e:
            logging.error(f"Errore connessione TCP: {e}")
            conn.close()

    def start_chat(self, event=None, username=None):
        """Avvia una chat privata con un utente."""
        if self.use_gui and not username:
            sel = self.users_listbox.curselection()
            if not sel:
                return
            username = self.users_listbox.get(sel[0]).split()[0]
        if username in self.chat_sessions:
            if self.use_gui:
                self.notebook.select(self.chat_tabs[username])
            return

        public_key, ip, _, _ = self.connected_users[username]
        shared_secret = self.private_key.exchange(ec.ECDH(), public_key)
        digest = hashes.Hash(hashes.SHA256())
        digest.update(shared_secret)
        aes_key = digest.finalize()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.connect((ip, 5001))
            sock.send(self.username.encode())
            chat_session = ChatSession(sock, aes_key, username, self)
            self.chat_sessions[username] = chat_session
            chat_session.start_listener()
            if self.use_gui:
                self.create_chat_tab(username, chat_session)
            else:
                self.cli_chat_loop(username)
            logging.info(f"Chat avviata con {username}")
        except Exception as e:
            logging.error(f"Errore avvio chat con {username}: {e}")
            if self.use_gui:
                messagebox.showerror("Errore", "Connessione fallita")
            else:
                print("Connessione fallita")
            sock.close()

    def create_chat_tab(self, username, chat_session):
        """Crea una scheda di chat nell'interfaccia grafica."""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text=username)
        self.chat_tabs[username] = tab
        text_area = tk.Text(tab, state='disabled', height=20)
        text_area.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        entry_frame = tk.Frame(tab)
        entry_frame.pack(fill=tk.X, padx=5, pady=5)
        entry = tk.Entry(entry_frame)
        entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entry.bind('<Return>', lambda e: self.send_message(chat_session, entry, text_area))
        tk.Button(entry_frame, text="Invia", command=lambda: self.send_message(chat_session, entry, text_area)).pack(side=tk.RIGHT)
        chat_session.text_area = text_area
        if username in self.message_history:
            text_area.config(state='normal')
            for msg in self.message_history[username]:
                text_area.insert(tk.END, f"{msg}\n")
            text_area.config(state='disabled')
            text_area.see(tk.END)

    def send_message(self, chat_session, entry, text_area):
        """Invia un messaggio nella chat."""
        msg = entry.get().strip()
        if msg:
            chat_session.send_message(msg)
            entry.delete(0, tk.END)
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            formatted_msg = f"[{timestamp}] Tu: {msg}"
            text_area.config(state='normal')
            text_area.insert(tk.END, f"{formatted_msg}\n")
            text_area.config(state='disabled')
            text_area.see(tk.END)
            if chat_session.username not in self.message_history:
                self.message_history[chat_session.username] = []
            self.message_history[chat_session.username].append(formatted_msg)
            self.save_message_history()

    def create_room_gui(self):
        """Crea una stanza tramite GUI."""
        room_name = simpledialog.askstring("Crea Stanza", "Nome della stanza:", parent=self.main_window)
        if room_name:
            self.create_room(room_name)

    def create_room(self, room_name):
        """Crea una nuova stanza di chat."""
        if room_name in self.rooms:
            if self.use_gui:
                messagebox.showinfo("Info", "Stanza già esistente")
            else:
                print("Stanza già esistente")
            return
        self.rooms[room_name] = set()
        if self.use_gui:
            self.rooms_listbox.insert(tk.END, room_name)
        self.join_room(room_name)
        logging.info(f"Stanza {room_name} creata da {self.username}")

    def join_room_gui(self, event):
        """Unisciti a una stanza tramite GUI."""
        sel = self.rooms_listbox.curselection()
        if not sel:
            return
        room_name = self.rooms_listbox.get(sel[0])
        self.join_room(room_name)

    def join_room(self, room_name):
        """Unisciti a una stanza di chat sul server dedicato."""
        if f"room:{room_name}" in self.chat_sessions:
            if self.use_gui:
                self.notebook.select(self.chat_tabs[f"room:{room_name}"])
            return
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.connect((self.server_host, self.server_port))
            sock.send(f"JOIN|{room_name}|{self.username}".encode())
            chat_session = ChatSession(sock, None, room_name, self, is_room=True)
            self.chat_sessions[f"room:{room_name}"] = chat_session
            chat_session.start_listener()
            if self.use_gui:
                self.create_chat_tab(f"room:{room_name}", chat_session)
            self.rooms[room_name].add(self.username)
            logging.info(f"{self.username} entrato nella stanza {room_name}")
        except Exception as e:
            logging.error(f"Errore unione stanza {room_name}: {e}")
            if self.use_gui:
                messagebox.showerror("Errore", "Connessione alla stanza fallita")
            sock.close()

    def cli_main_loop(self):
        """Ciclo principale per l'interfaccia CLI."""
        while True:
            os.system('cls' if os.name == 'nt' else 'clear')
            print(f"--- Secure Chat ({self.username}) ---")
            print("Utenti connessi:")
            users = sorted(self.connected_users.keys())
            for i, u in enumerate(users, 1):
                status = self.connected_users[u][3]
                print(f"{i}. {u} ({status})")
            print("\nStanze:")
            for i, r in enumerate(self.rooms.keys(), 1):
                print(f"{i}. {r}")
            print("\nOpzioni:")
            print("c <numero> - Chatta con utente")
            print("r <numero> - Entra in stanza")
            print("n <nome> - Crea nuova stanza")
            print("u - Aggiorna lista")
            print("q - Esci")
            choice = input("> ").strip().lower()
            if choice == 'q':
                self.on_closing()
                break
            elif choice == 'u':
                continue
            elif choice.startswith('c '):
                try:
                    num = int(choice.split()[1]) - 1
                    if 0 <= num < len(users):
                        self.start_chat(username=users[num])
                    else:
                        input("Numero non valido. Premi Invio...")
                except:
                    input("Errore input. Premi Invio...")
            elif choice.startswith('r '):
                try:
                    num = int(choice.split()[1]) - 1
                    rooms = list(self.rooms.keys())
                    if 0 <= num < len(rooms):
                        self.join_room(rooms[num])
                    else:
                        input("Numero non valido. Premi Invio...")
                except:
                    input("Errore input. Premi Invio...")
            elif choice.startswith('n '):
                room_name = choice.split(maxsplit=1)[1].strip()
                self.create_room(room_name)
            else:
                input("Comando non valido. Premi Invio...")

    def cli_chat_loop(self, username):
        """Ciclo di chat CLI per chat private."""
        os.system('cls' if os.name == 'nt' else 'clear')
        print(f"--- Chat con {username} ---")
        print("Digita 'exit' per tornare al menu")
        if username in self.message_history:
            for msg in self.message_history[username]:
                print(msg)
        while True:
            msg = input("Tu: ").strip()
            if msg.lower() == 'exit':
                break
            if username in self.chat_sessions:
                self.chat_sessions[username].send_message(msg)
            else:
                print("Sessione interrotta")
                break
        input("Premi Invio per tornare...")

    def on_closing(self):
        """Gestisce la chiusura dell'applicazione."""
        for session in self.chat_sessions.values():
            session.sock.close()
        self.save_message_history()
        if self.use_gui:
            self.main_window.destroy()
            self.window.destroy()
        logging.info(f"Utente {self.username} disconnesso")
        sys.exit(0)

class ChatSession:
    def __init__(self, sock, aes_key, username, app, is_room=False):
        self.sock = sock
        self.aes_key = aes_key
        self.username = username
        self.app = app
        self.is_room = is_room
        self.send_counter = 0
        self.text_area = None

    def start_listener(self):
        """Avvia il thread per ascoltare i messaggi."""
        threading.Thread(target=self.listen_for_messages, daemon=True).start()

    def listen_for_messages(self):
        """Ascolta i messaggi in arrivo."""
        while True:
            try:
                length_bytes = self.sock.recv(4)
                if not length_bytes:
                    break
                length = int.from_bytes(length_bytes, 'big')
                msg = self.sock.recv(length)
                if not msg:
                    break
                if self.is_room:
                    plaintext = msg.decode()
                else:
                    nonce = msg[:12]
                    tag = msg[-16:]
                    ciphertext = msg[12:-16]
                    cipher = Cipher(algorithms.AES(self.aes_key), modes.GCM(nonce, tag))
                    decryptor = cipher.decryptor()
                    plaintext = decryptor.update(ciphertext) + decryptor.finalize().decode()
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                formatted_msg = f"[{timestamp}] {self.username}: {plaintext}"
                if self.app.use_gui:
                    if self.text_area:
                        self.text_area.config(state='normal')
                        self.text_area.insert(tk.END, f"{formatted_msg}\n")
                        self.text_area.config(state='disabled')
                        self.text_area.see(tk.END)
                else:
                    print(formatted_msg)
                if not self.is_room:
                    if self.username not in self.app.message_history:
                        self.app.message_history[self.username] = []
                    self.app.message_history[self.username].append(formatted_msg)
                    self.app.save_message_history()
            except Exception as e:
                logging.error(f"Errore ricezione messaggio da {self.username}: {e}")
                break
        self.sock.close()
        if self.username in self.app.chat_sessions:
            del self.app.chat_sessions[self.username]

    def send_message(self, message):
        """Invia un messaggio."""
        if self.is_room:
            msg = message.encode()
        else:
            nonce = self.send_counter.to_bytes(12, 'big')
            self.send_counter += 1
            cipher = Cipher(algorithms.AES(self.aes_key), modes.GCM(nonce))
            encryptor = cipher.encryptor()
            ciphertext = encryptor.update(message.encode()) + encryptor.finalize()
            msg = nonce + ciphertext + encryptor.tag
        length = len(msg)
        try:
            self.sock.send(length.to_bytes(4, 'big') + msg)
            logging.info(f"Messaggio inviato a {self.username}: {message}")
        except Exception as e:
            logging.error(f"Errore invio messaggio a {self.username}: {e}")

if __name__ == "__main__":
    ChatApp()