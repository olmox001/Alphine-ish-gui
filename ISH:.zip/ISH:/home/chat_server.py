import socket
import threading
import logging

# Configurazione del logging
logging.basicConfig(filename='server.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

class ChatServer:
    def __init__(self, host='0.0.0.0', port=5002):
        self.host = host
        self.port = port
        self.rooms = {}  # {room_name: {client_socket: username}}
        self.lock = threading.Lock()
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((self.host, self.port))
        self.sock.listen(5)
        logging.info(f"Server avviato su {self.host}:{self.port}")

    def start(self):
        """Avvia il server e accetta connessioni dai client."""
        while True:
            conn, addr = self.sock.accept()
            threading.Thread(target=self.handle_client, args=(conn, addr), daemon=True).start()

    def handle_client(self, conn, addr):
        """Gestisce un client connesso."""
        try:
            # Riceve il messaggio di join
            data = conn.recv(1024).decode().strip()
            if not data:
                return
            parts = data.split('|')
            if len(parts) != 3 or parts[0] != "JOIN":
                conn.close()
                return
            _, room_name, username = parts

            # Aggiunge il client alla stanza
            with self.lock:
                if room_name not in self.rooms:
                    self.rooms[room_name] = {}
                self.rooms[room_name][conn] = username
            logging.info(f"{username} entrato in {room_name} da {addr}")

            # Gestisce i messaggi del client
            while True:
                length_bytes = conn.recv(4)
                if not length_bytes:
                    break
                length = int.from_bytes(length_bytes, 'big')
                msg = conn.recv(length)
                if not msg:
                    break
                self.broadcast(room_name, msg, conn)
        except Exception as e:
            logging.error(f"Errore gestione client {addr}: {e}")
        finally:
            # Rimuove il client dalla stanza alla disconnessione
            with self.lock:
                for room_name, clients in self.rooms.items():
                    if conn in clients:
                        del clients[conn]
                        if not clients:
                            del self.rooms[room_name]
                        break
            conn.close()
            logging.info(f"Client {addr} disconnesso")

    def broadcast(self, room_name, msg, sender_conn):
        """Invia un messaggio a tutti i client nella stanza eccetto il mittente."""
        with self.lock:
            for client in self.rooms[room_name]:
                if client != sender_conn:
                    try:
                        client.send(len(msg).to_bytes(4, 'big') + msg)
                    except Exception:
                        pass

if __name__ == "__main__":
    server = ChatServer()
    server.start()