#!/usr/bin/env python3

import os
import platform
import subprocess
import sys
import time
import getpass
import socket
import json
import threading
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidTag
import colorama
from colorama import Fore, Style, init
import shutil

# Inizializza colorama
init()

# Bootloader per verificare sistema e librerie
def bootloader():
    print("Avvio del bootloader...")
    system = platform.system()
    print(f"Sistema operativo rilevato: {system}")

    # Verifica della versione di Python
    if sys.version_info < (3, 6):
        print("Errore: Questo programma richiede Python 3.6 o superiore.")
        sys.exit(1)

    # Verifica della presenza di pip
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"])
    except subprocess.CalledProcessError:
        print("Errore: pip non è installato. Installa pip e riprova.")
        sys.exit(1)

    # Lista delle librerie necessarie
    libraries = ['cryptography', 'colorama']
    for lib in libraries:
        try:
            __import__(lib)
            print(f"{lib} è già installata.")
        except ImportError:
            print(f"{lib} non è installata. Procedo con l'installazione.")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
                print(f"Installazione di {lib} completata.")
            except subprocess.CalledProcessError:
                print(f"Errore durante l'installazione di {lib}. Verifica la connessione internet e i permessi.")
                sys.exit(1)

    # Barra di caricamento visiva
    print("Verifica in corso", end='', flush=True)
    for _ in range(10):
        print(".", end='', flush=True)
        time.sleep(0.1)
    print("\nBootloader completato. Avvio del programma.")

# Avvio del bootloader
bootloader()

# Funzione per ottenere la password con asterischi
def get_password_with_stars(prompt):
    return getpass.getpass(prompt)

# Funzione di crittografia del file
def encrypt_file(plaintext, password_file, password_system, username, ip, original_extension):
    # Deriva K_file per il contenuto
    salt_file = os.urandom(16)
    kdf_file = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 256 bit
        salt=salt_file,
        iterations=600000,
        backend=default_backend()
    )
    K_file = kdf_file.derive(password_file.encode())
    iv_content = os.urandom(12)
    cipher_content = Cipher(algorithms.AES(K_file), modes.GCM(iv_content), backend=default_backend())
    encryptor_content = cipher_content.encryptor()
    content_with_extension = json.dumps({"extension": original_extension}).encode('utf-8') + plaintext
    ciphertext_content = encryptor_content.update(content_with_extension) + encryptor_content.finalize()
    tag_content = encryptor_content.tag

    # Crea e cripta la sezione finale con IP e username
    section_plain = json.dumps({"ip": ip, "username": username}).encode('utf-8')
    salt_section = os.urandom(16)
    combined_password = password_file + ":" + password_system
    kdf_section = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 256 bit
        salt=salt_section,
        iterations=600000,
        backend=default_backend()
    )
    K_section = kdf_section.derive(combined_password.encode())
    iv_section = os.urandom(12)
    cipher_section = Cipher(algorithms.AES(K_section), modes.GCM(iv_section), backend=default_backend())
    encryptor_section = cipher_section.encryptor()
    ciphertext_section = encryptor_section.update(section_plain) + encryptor_section.finalize()
    tag_section = encryptor_section.tag

    # Costruisci il file criptato
    len_content = len(ciphertext_content).to_bytes(4, 'big')
    data = (len_content + salt_file + iv_content + tag_content + ciphertext_content +
            salt_section + iv_section + tag_section + ciphertext_section)
    return data

# Funzione di decriptazione del contenuto
def decrypt_content(encrypted_data, password_file):
    len_content = int.from_bytes(encrypted_data[:4], 'big')
    salt_file = encrypted_data[4:20]
    iv_content = encrypted_data[20:32]
    tag_content = encrypted_data[32:48]
    ciphertext_content = encrypted_data[48:48 + len_content]
    kdf_file = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_file,
        iterations=600000,
        backend=default_backend()
    )
    K_file = kdf_file.derive(password_file.encode())
    cipher_content = Cipher(algorithms.AES(K_file), modes.GCM(iv_content, tag_content), backend=default_backend())
    decryptor_content = cipher_content.decryptor()
    plaintext = decryptor_content.update(ciphertext_content) + decryptor_content.finalize()
    return plaintext

# Funzione di decriptazione della sezione
def decrypt_section(encrypted_data, password_file, password_system):
    len_content = int.from_bytes(encrypted_data[:4], 'big')
    offset = 4 + 16 + 12 + 16 + len_content
    salt_section = encrypted_data[offset:offset + 16]
    iv_section = encrypted_data[offset + 16:offset + 28]
    tag_section = encrypted_data[offset + 28:offset + 44]
    ciphertext_section = encrypted_data[offset + 44:]
    combined_password = password_file + ":" + password_system
    kdf_section = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt_section,
        iterations=600000,
        backend=default_backend()
    )
    K_section = kdf_section.derive(combined_password.encode())
    cipher_section = Cipher(algorithms.AES(K_section), modes.GCM(iv_section, tag_section), backend=default_backend())
    decryptor_section = cipher_section.decryptor()
    section_plain = decryptor_section.update(ciphertext_section) + decryptor_section.finalize()
    return section_plain

def clear_screen():
    """Cancella lo schermo e riposiziona il cursore in alto a sinistra."""
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

# File explorer migliorato
def file_explorer(start_dir, select_file=False):
    current_dir = start_dir
    while True:
        clear_screen()
        print(f"Directory corrente: {current_dir}")
        items = os.listdir(current_dir)
        dirs = [item for item in items if os.path.isdir(os.path.join(current_dir, item))]
        files = [item for item in items if os.path.isfile(os.path.join(current_dir, item))]
        
        if dirs:
            print("Cartelle disponibili:")
            for i, d in enumerate(dirs, 1):
                print(f"{i}. {d}")
        else:
            print("Nessuna cartella disponibile.")
        
        if select_file and files:
            print("File disponibili:")
            for i, f in enumerate(files, 1):
                print(f"{i}. {f}")
        elif select_file:
            print("Nessun file disponibile.")
        
        command = input("Inserisci 'cd <numero>' per cambiare cartella, 'select' per selezionare la directory corrente, 'select <numero>' per selezionare un file, 'back' per tornare indietro, 'exit' per uscire: ").strip().lower()
        
        if command == "back":
            current_dir = os.path.dirname(current_dir)
        elif command.startswith("cd "):
            try:
                num = int(command[3:].strip())
                if 1 <= num <= len(dirs):
                    current_dir = os.path.join(current_dir, dirs[num-1])
                else:
                    print("Numero cartella non valido.")
            except ValueError:
                print("Comando non valido. Usa 'cd <numero>'.")
        elif command == "select":
            return current_dir
        elif select_file and command.startswith("select "):
            try:
                num = int(command[7:].strip())
                if 1 <= num <= len(files):
                    return os.path.join(current_dir, files[num-1])
                else:
                    print("Numero file non valido.")
            except ValueError:
                print("Comando non valido. Usa 'select <numero>'.")
        elif command == "exit":
            return None
        else:
            print("Comando non valido.")

# Processo di crittografia
def encrypt_process(password_system, username, ip):
    while True:
        try:
            clear_screen()
            print("\n=== Opzioni di Crittografia ===")
            print("a. Crea un nuovo file criptato scrivendo del testo")
            print("b. Cripta un file esistente")
            sub_choice = input("Scegli un'opzione (a o b): ").strip().lower()
            while sub_choice not in ['a', 'b']:
                print("Errore: opzione non valida.")
                sub_choice = input("Scegli un'opzione (a o b): ").strip().lower()
            
            if sub_choice == 'a':
                plaintext = input("Inserisci il testo da criptare: ").encode('utf-8')
                original_extension = ".txt"
            else:
                print("Seleziona il file da criptare.")
                input_path = file_explorer(os.getcwd(), select_file=True)
                if not input_path:
                    return
                print(f"File selezionato: {input_path}")  # Debug print
                with open(input_path, 'rb') as f:
                    plaintext = f.read()
                original_extension = os.path.splitext(input_path)[1]
            
            print("Seleziona la cartella di destinazione (digita 'exit' per uscire).")
            output_dir = file_explorer(os.getcwd(), select_file=False)
            if not output_dir:
                return
            print(f"Cartella di destinazione: {output_dir}")  # Debug print
            output_name = input("Inserisci il nome del file criptato (senza estensione): ").strip()
            while not output_name:
                print("Errore: il nome non può essere vuoto.")
                output_name = input("Inserisci il nome del file criptato (senza estensione): ").strip()
            output_path = os.path.join(output_dir, output_name + '.crypto')
            print(f"Percorso del file criptato: {output_path}")  # Debug print
            
            password_file = get_password_with_stars("Inserisci la password per il file (min 8 caratteri): ")
            while len(password_file) < 8:
                print("Errore: la password deve essere lunga almeno 8 caratteri.")
                password_file = get_password_with_stars("Inserisci la password per il file (min 8 caratteri): ")
            
            encrypted_data = encrypt_file(plaintext, password_file, password_system, username, ip, original_extension)
            with open(output_path, 'wb') as f:
                f.write(encrypted_data)
            print(f"File criptato salvato in {output_path}")
            break
        except Exception as e:
            print(f"Errore durante la crittografia: {e}")
            retry = input("Vuoi riprovare? (s/n): ").strip().lower()
            if retry != 's':
                break

# Processo di decriptazione del contenuto
def decrypt_content_process():
    while True:
        try:
            clear_screen()
            print("Seleziona il file criptato (deve avere estensione .crypto).")
            input_path = file_explorer(os.getcwd(), select_file=True)
            if not input_path or not input_path.endswith('.crypto'):
                print("Errore: il file deve avere estensione .crypto")
                return
            print("Seleziona la cartella di destinazione (digita 'exit' per uscire).")
            output_dir = file_explorer(os.getcwd(), select_file=False)
            if not output_dir:
                return
            output_name = input("Inserisci il nome del file decriptato (senza estensione): ").strip()
            while not output_name:
                print("Errore: il nome non può essere vuoto.")
                output_name = input("Inserisci il nome del file decriptato (senza estensione): ").strip()
            
            with open(input_path, 'rb') as f:
                encrypted_data = f.read()
            
            password_file = get_password_with_stars("Inserisci la password del file: ")
            plaintext_with_extension = decrypt_content(encrypted_data, password_file)
            extension_data, plaintext = plaintext_with_extension.split(b'}', 1)
            extension = json.loads(extension_data.decode('utf-8') + '}')["extension"]
            output_path = os.path.join(output_dir, output_name + extension)
            
            with open(output_path, 'wb') as f:
                f.write(plaintext)
            print(f"File decriptato salvato in {output_path}")
            break
        except InvalidTag:
            print("Errore: password errata o dati corrotti.")
        except json.JSONDecodeError:
            print("Errore: dati della sezione corrotti.")
        except Exception as e:
            print(f"Errore durante la decriptazione: {e}")
            retry = input("Vuoi riprovare? (s/n): ").strip().lower()
            if retry != 's':
                break

# Processo di lettura della sezione
def read_section_process(password_system):
    while True:
        try:
            clear_screen()
            print("Seleziona il file criptato (deve avere estensione .crypto).")
            input_path = file_explorer(os.getcwd(), select_file=True)
            if not input_path or not input_path.endswith('.crypto'):
                print("Errore: il file deve avere estensione .crypto")
                return
            with open(input_path, 'rb') as f:
                encrypted_data = f.read()
            
            password_file = get_password_with_stars("Inserisci la password del file: ")
            section_plain = decrypt_section(encrypted_data, password_file, password_system)
            section = json.loads(section_plain.decode('utf-8'))
            print(f"Sezione decrittata: IP = {section['ip']}, Username = {section['username']}")
            input("Premi Invio per continuare...")
            break
        except InvalidTag:
            print("Errore: password errata o dati corrotti.")
        except json.JSONDecodeError:
            print("Errore: dati della sezione corrotti.")
        except Exception as e:
            print(f"Errore durante la lettura della sezione: {e}")
            retry = input("Vuoi riprovare? (s/n): ").strip().lower()
            if retry != 's':
                break

# Funzioni aggiuntive per la rete e la chat room
def start_network_server():
    # Implementa la logica per avviare il server di rete
    print("Avvio del server di rete...")

def send_message(room_id, username, message, room_key, ip, port):
    encrypted_message = encrypt_file(message.encode('utf-8'), room_key, room_key, username, ip, ".txt")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        s.sendall(encrypted_message)

def receive_message(port, room_key):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', port))
        s.listen()
        conn, addr = s.accept()
        with conn:
            encrypted_data = conn.recv(1024)
            message = decrypt_content(encrypted_data, room_key)
            print(f"Received message: {message.decode('utf-8')}")

def handle_client(conn, addr, room_key, log_path):
    with conn:
        print(f"Connessione da {addr}")
        while True:
            data = conn.recv(1024)
            if not data:
                break
            try:
                decrypted_data = decrypt_content(data, room_key)
                message = decrypted_data.decode('utf-8')
                print(f"Messaggio ricevuto: {message}")
                with open(log_path, 'ab') as log_file:
                    log_file.write(data + b'\n')
            except InvalidTag:
                print("Errore: dati corrotti o chiave errata.")

def server_thread(port, room_key, log_path):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', port))
        s.listen()
        print(f"Server chat avviato sulla porta {port}")
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr, room_key, log_path)).start()

def start_chat_server(port, room_key):
    room_dir = os.path.join(os.getcwd(), 'temp_room')
    os.makedirs(room_dir, exist_ok=True)
    log_path = os.path.join(room_dir, 'chat_log.enc')
    threading.Thread(target=server_thread, args=(port, room_key, log_path)).start()

# Funzione per generare una chiave di stanza
def generate_room_key(ip, room_key, room_name):
    combined = f"{ip}:{room_key}:{room_name}".encode('utf-8')
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=os.urandom(16),
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(combined)

# Funzione per creare una stanza
def create_room(room_key, username, ip):
    room_key = get_password_with_stars("Inserisci la password per la stanza (max 10 caratteri): ")
    while len(room_key) > 10:
        print("Errore: la password deve essere lunga massimo 10 caratteri.")
        room_key = get_password_with_stars("Inserisci la password per la stanza (max 10 caratteri): ")
    port = int(input("Inserisci il numero di porta: ").strip())
    room_name = input("Inserisci il nome della stanza: ").strip()
    room_key_256 = generate_room_key(ip, room_key, room_name)
    start_chat_server(port, room_key_256)
    print(f"Stanza creata con IP: {ip} e porta: {port}")
    return room_key_256, port, room_name

# Funzione per unirsi a una stanza
def join_room(room_key, username, ip):
    ip_address = input("Inserisci l'indirizzo IP della stanza: ").strip()
    port = int(input("Inserisci il numero di porta: ").strip())
    room_key = get_password_with_stars("Inserisci la password della stanza (max 10 caratteri): ")
    while len(room_key) > 10:
        print("Errore: la password deve essere lunga massimo 10 caratteri.")
        room_key = get_password_with_stars("Inserisci la password della stanza (max 10 caratteri): ")
    room_name = input("Inserisci il nome della stanza: ").strip()
    room_key_256 = generate_room_key(ip_address, room_key, room_name)
    print(f"Unito alla stanza {room_name} con IP: {ip_address} e porta: {port}")
    return room_key_256, ip_address, port, room_name

# Funzione per gestire la stanza
def manage_room(room_key, port, room_name, username, ip):
    room_dir = os.path.join(os.getcwd(), f'temp_room_{room_name}')
    log_path = os.path.join(room_dir, 'chat_log.enc')
    tephp_path = os.path.join(room_dir, 'info.php.crypto')
    
    # Creare il file textchat.kchat se non esiste
    if not os.path.exists(php_path):
        with open(php_path, 'wb') as f:
            f.write(b'')
    
    # Decriptare e leggere il file PHP
    php_path = os.path.join(room_dir, 'info.php.crypto')
    if os.path.exists(php_path):
        with open(php_path, 'rb') as f:
            encrypted_php = f.read()
        try:
            php_content = decrypt_content(encrypted_php, room_key)
            print(php_content.decode('utf-8'))
        except InvalidTag:
            print("Errore: dati corrotti o chiave errata.")
    
    while True:
        clear_screen()
        print(Fore.YELLOW + f"Indirizzo IP della stanza: {ip}")
        print(f"Nome della stanza: {room_name}")
        print(f"Password della stanza: {room_key.decode('utf-8')}")
        print(Fore.GREEN + f"Nome utente: {username}")
        print(Style.RESET_ALL)
        print("\n=== Gestione Stanza ===")
        print("1. Visualizza utenti connessi")
        print("2. Visualizza file caricati")
        print("3. Invia messaggio")
        print("4. Invia file")
        print("5. Scarica file")
        print("6. Esci dalla stanza")
        choice = input("Scegli un'opzione (1-6): ").strip()
        
        if choice == '1':
            with open(log_path, 'rb') as log_file:
                for line in log_file:
                    print(line.decode('utf-8'))
        elif choice == '2':
            files = [f for f in os.listdir(room_dir) if f.endswith('.crypto') and f != 'info.php.crypto']
            for file in files:
                file_path = os.path.join(room_dir, file)
                with open(file_path, 'rb') as f:
                    encrypted_data = f.read()
                try:
                    section_plain = decrypt_section(encrypted_data, room_key, room_key)
                    section = json.loads(section_plain.decode('utf-8'))
                    print(f"{file} - IP: {section['ip']}, Username: {section['username']}")
                except InvalidTag:
                    print(f"{file} - Errore: dati corrotti o chiave errata.")
        elif choice == '3':
            message_menu(room_key, textchat_path, username, ip)
        elif choice == '4':
            print("Seleziona il file da inviare.")
            input_path = file_explorer(os.getcwd(), select_file=True)
            if not input_path:
                continue
            with open(input_path, 'rb') as f:
                plaintext = f.read()
            encrypted_data = encrypt_file(plaintext, room_key, room_key, username, ip, os.path.splitext(input_path)[1])
            with open(os.path.join(room_dir, os.path.basename(input_path) + '.crypto'), 'wb') as f:
                f.write(encrypted_data)
            print(f"File {os.path.basename(input_path)} inviato.")
        elif choice == '5':
            print("Seleziona il file da scaricare.")
            files = [f for f in os.listdir(room_dir) if f.endswith('.crypto') and f != 'info.php.crypto']
            for i, file in enumerate(files, 1):
                print(f"{i}. {file}")
            file_choice = input("Scegli un file (numero) o digita 'back' per tornare indietro: ").strip()
            if file_choice.lower() == 'back':
                continue
            try:
                file_choice = int(file_choice)
                if 1 <= file_choice <= len(files):
                    file_path = os.path.join(room_dir, files[file_choice - 1])
                    with open(file_path, 'rb') as f:
                        encrypted_data = f.read()
                    plaintext_with_extension = decrypt_content(encrypted_data, room_key)
                    extension_data, plaintext = plaintext_with_extension.split(b'}', 1)
                    extension = json.loads(extension_data.decode('utf-8') + '}')["extension"]
                    output_dir = file_explorer(os.getcwd(), select_file=False)
                    if not output_dir:
                        continue
                    output_path = os.path.join(output_dir, os.path.basename(file_path).replace('.crypto', extension))
                    with open(output_path, 'wb') as f:
                        f.write(plaintext)
                    print(f"File {os.path.basename(file_path)} scaricato e decriptato in {output_path}.")
                else:
                    print("Errore: opzione non valida.")
            except ValueError:
                print("Errore: opzione non valida.")
        elif choice == '6':
            print("Uscita dalla stanza.")
            break
        else:
            print("Errore: opzione non valida.")
        input("Premi Invio per continuare...")
    
    # Cancella la cartella temporanea quando si esce dalla stanza
    shutil.rmtree(room_dir)

def start_chat_server_menu(room_key, username, ip):
    while True:
        clear_screen()
        print("\n=== Server Chat ===")
        print("1. Crea una nuova stanza")
        print("2. Unisciti a una stanza esistente")
        print("3. Torna al menu principale")
        choice = input("Scegli un'opzione (1-3): ").strip()
        
        if choice == '1':
            room_key, port, room_name = create_room(room_key, username, ip)
            manage_room(room_key, port, room_name, username, ip)
        elif choice == '2':
            room_key, ip_address, port, room_name = join_room(room_key, username, ip)
            manage_room(room_key, port, room_name, username, ip_address)
        elif choice == '3':
            break
        else:
            print("Errore: opzione non valida.")
        input("Premi Invio per continuare...")

# Aggiornamento del menu principale
def main():
    clear_screen()
    print("Benvenuto nel programma di crittografia.")
    username = input("Inserisci il tuo nome utente: ").strip()
    password_system = get_password_with_stars("Inserisci la tua password di sistema: ")
    ip = socket.gethostbyname(socket.gethostname())
    print(f"IP rilevato: {ip}")
   
    while True:
        clear_screen()
        print("\n=== Programma di Crittografia ===")
        print("1. Crittografa")
        print("2. Decrittografa contenuto")
        print("3. Leggi sezione")
        print("4. Avvia server chat")
        print("5. Esci")
        choice = input("Scegli un'opzione (1-5): ").strip()
       
        if choice == '1':
            encrypt_process(password_system, username, ip)
        elif choice == '2':
            decrypt_content_process()
        elif choice == '3':
            read_section_process(password_system)
        elif choice == '4':
            start_chat_server_menu(password_system, username, ip)
        elif choice == '5':
            print("Uscita dal programma.")
            break
        else:
            print("Errore: opzione non valida.")
   
    print(colorama.Style.RESET_ALL)

def clear_old_rooms():
    print("Clearing old rooms...")
    old_rooms_dir = os.path.join(os.getcwd(), 'temp_room')
    if os.path.exists(old_rooms_dir):
        shutil.rmtree(old_rooms_dir)
    print("Old rooms cleared.")

if __name__ == "__main__":
    try:
        main()
    finally:
        clear_old_rooms()