import platform
import subprocess
import sys
import os
import tempfile
import getpass
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.backends import default_backend
import socket
import threading
import hashlib

# **Variabili globali**
temp_dir = None  # Directory temporanea
user_key = None  # Chiave utente derivata dal login
rooms = {}       # Dizionario delle stanze di rete
server_running = False  # Stato del server di rete
os_type = None   # Tipo di sistema operativo

# **Bootloader: rileva OS e configura l'ambiente**
def bootloader():
    global temp_dir, os_type
    os_type = platform.system()
    print(f"Sistema operativo: {os_type}")
    try:
        import cryptography
    except ImportError:
        print("Installazione cryptography...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "cryptography"])
    temp_dir = tempfile.mkdtemp()
    print(f"Directory temporanea: {temp_dir}")

# **Login sicuro: genera una chiave a 256 bit da username e password**
def secure_login():
    global user_key
    username = input("Nome utente: ")
    password = getpass.getpass("Password: ")
    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 256 bit
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    user_key = kdf.derive((username + password).encode())

# **Crittografia file: usa AES-GCM con chiave derivata**
def encrypt_file(file_path, key):
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    with open(file_path, "rb") as f:
        data = f.read()
    ciphertext = aesgcm.encrypt(nonce, data, None)
    encrypted_file_path = file_path + ".lock"
    with open(encrypted_file_path, "wb") as f:
        f.write(nonce + ciphertext)
    return encrypted_file_path

# **Decrittografia file: usa AES-GCM con chiave derivata**
def decrypt_file(encrypted_file_path, key):
    if not encrypted_file_path.endswith(".lock"):
        print("File non criptato")
        return None
    with open(encrypted_file_path, "rb") as f:
        nonce = f.read(12)
        ciphertext = f.read()
    aesgcm = AESGCM(key)
    try:
        data = aesgcm.decrypt(nonce, ciphertext, None)
        original_file_path = encrypted_file_path[:-5]
        with open(original_file_path, "wb") as f:
            f.write(data)
        return original_file_path
    except Exception as e:
        print(f"Errore decrittografia: {e}")
        return None

# **Selezione file: grafica con tkinter o testuale**
def select_file(use_graphical, prompt):
    if use_graphical:
        try:
            from tkinter import Tk
            from tkinter.filedialog import askopenfilename
            root = Tk()
            root.withdraw()
            file_path = askopenfilename()
            root.destroy()
            return file_path
        except ImportError:
            print("tkinter non disponibile, uso modo testuale")
    return input(prompt)

# **Apri file explorer: grafico in base al sistema operativo**
def open_file_explorer(path):
    if os_type == "Windows":
        os.startfile(path)
    elif os_type == "Linux":
        subprocess.call(["xdg-open", path])
    elif os_type == "Darwin":
        subprocess.call(["open", path])
    else:
        print("Sistema operativo non supportato")

# **File manager testuale: navigare e gestire file**
def text_file_manager(current_path):
    while True:
        print(f"Directory corrente: {current_path}")
        items = os.listdir(current_path)
        dirs = [item for item in items if os.path.isdir(os.path.join(current_path, item))]
        files = [item for item in items if os.path.isfile(os.path.join(current_path, item))]
        for i, d in enumerate(dirs, 1):
            print(f"{i}. [{d}]")
        for i, f in enumerate(files, len(dirs) + 1):
            print(f"{i}. {f}")
        cmd = input("Comando (cd <num>, cd 0, back, read <num>, cript <num>): ").strip().lower()
        parts = cmd.split()
        if len(parts) == 0:
            continue
        if parts[0] == "cd":
            if len(parts) == 2:
                if parts[1] == "0":
                    current_path = os.path.dirname(current_path)
                else:
                    try:
                        num = int(parts[1]) - 1
                        if 0 <= num < len(dirs):
                            current_path = os.path.join(current_path, dirs[num])
                        else:
                            print("Numero non valido")
                    except ValueError:
                        print("Numero non valido")
            else:
                print("Uso: cd <numero> o cd 0")
        elif parts[0] == "back":
            break
        elif parts[0] == "read":
            if len(parts) == 2:
                try:
                    num = int(parts[1]) - 1 - len(dirs)
                    if 0 <= num < len(files):
                        file_path = os.path.join(current_path, files[num])
                        stat = os.stat(file_path)
                        print(f"File: {files[num]}, Dimensione: {stat.st_size} byte")
                    else:
                        print("Numero non valido")
                except ValueError:
                    print("Numero non valido")
            else:
                print("Uso: read <numero>")
        elif parts[0] == "cript":
            if len(parts) == 2:
                try:
                    num = int(parts[1]) - 1 - len(dirs)
                    if 0 <= num < len(files):
                        file_path = os.path.join(current_path, files[num])
                        if file_path.endswith(".lock"):
                            new_path = decrypt_file(file_path, user_key)
                            if new_path:
                                print(f"Decrittografato in {new_path}")
                            else:
                                print("Decrittografia fallita")
                        else:
                            new_path = encrypt_file(file_path, user_key)
                            print(f"Criptato in {new_path}")
                    else:
                        print("Numero non valido")
                except ValueError:
                    print("Numero non valido")
            else:
                print("Uso: cript <numero>")
        else:
            print("Comando non riconosciuto")

# **Server per le stanze di rete**
def room_server():
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.bind(("0.0.0.0", 5000))
    server_sock.listen(5)
    print("Server in ascolto su porta 5000")
    while True:
        client_sock, addr = server_sock.accept()
        threading.Thread(target=handle_client, args=(client_sock,)).start()

# **Gestione client nella stanza di rete**
def handle_client(client_sock):
    try:
        client_sock.send(b"ROOM?")
        room_name = client_sock.recv(1024).decode().strip()
        if room_name not in rooms:
            client_sock.send(b"NO_ROOM")
            client_sock.close()
            return
        room = rooms[room_name]
        client_sock.send(room['salt'])
        received_hash = client_sock.recv(1024)
        if received_hash != room['hashed_password']:
            client_sock.send(b"WRONG_PASSWORD")
            client_sock.close()
            return
        client_sock.send(b"OK")
        room['clients'].append(client_sock)
        while True:
            data = client_sock.recv(1024)
            if not data:
                break
            if data.startswith(b"CHAT:"):
                message = data[5:].decode()
                for c in room['clients']:
                    if c != client_sock:
                        c.send(f"CHAT:{message}".encode())
            elif data.startswith(b"UPLOAD:"):
                parts = data.split(b":", 2)
                if len(parts) == 3:
                    filename = parts[1].decode()
                    file_data = parts[2]
                    file_path = os.path.join(room['files_dir'], filename + ".lock")
                    with open(file_path, "wb") as f:
                        f.write(file_data)
                    for c in room['clients']:
                        c.send(f"NEW_FILE:{filename}".encode())
            elif data.startswith(b"DOWNLOAD:"):
                filename = data[9:].decode()
                file_path = os.path.join(room['files_dir'], filename + ".lock")
                if os.path.exists(file_path):
                    with open(file_path, "rb") as f:
                        file_data = f.read()
                    client_sock.send(file_data)
                else:
                    client_sock.send(b"FILE_NOT_FOUND")
    except Exception as e:
        print(f"Errore client: {e}")
    finally:
        if 'room' in locals() and client_sock in room['clients']:
            room['clients'].remove(client_sock)
        client_sock.close()

# **Crea una stanza di rete**
def create_room():
    global server_running
    room_name = input("Nome stanza: ")
    room_password = getpass.getpass("Password stanza: ")
    salt = os.urandom(16)
    hashed_password = hashlib.sha256(salt + room_name.encode() + room_password.encode()).digest()
    room_dir = os.path.join(temp_dir, room_name)
    os.makedirs(room_dir, exist_ok=True)
    files_dir = os.path.join(room_dir, "files")
    os.makedirs(files_dir, exist_ok=True)
    rooms[room_name] = {
        'salt': salt,
        'hashed_password': hashed_password,
        'clients': [],
        'files_dir': files_dir
    }
    if not server_running:
        threading.Thread(target=room_server, daemon=True).start()
        server_running = True
    print(f"Stanza {room_name} creata.")

# **Accedi a una stanza di rete**
def access_room():
    room_name = input("Nome stanza: ")
    room_password = getpass.getpass("Password stanza: ")
    client_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_sock.connect(("localhost", 5000))
    msg = client_sock.recv(1024).decode()
    if msg == "ROOM?":
        client_sock.send(room_name.encode())
    data = client_sock.recv(1024)
    if data == b"NO_ROOM":
        print("Stanza non trovata")
        client_sock.close()
        return
    salt = data
    hashed_password = hashlib.sha256(salt + room_name.encode() + room_password.encode()).digest()
    client_sock.send(hashed_password)
    response = client_sock.recv(1024).decode()
    if response == "WRONG_PASSWORD":
        print("Password errata")
        client_sock.close()
        return
    elif response == "OK":
        print("Connesso alla stanza")
        # Deriva la chiave della stanza
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        room_key = kdf.derive((room_name + room_password).encode())
        # Thread per ricevere messaggi
        def receive_messages():
            while True:
                try:
                    data = client_sock.recv(1024)
                    if not data:
                        break
                    if data.startswith(b"CHAT:"):
                        message = data[5:].decode()
                        print(f"Messaggio: {message}")
                    elif data.startswith(b"NEW_FILE:"):
                        filename = data[9:].decode()
                        print(f"Nuovo file caricato: {filename}")
                except Exception as e:
                    print(f"Errore ricezione: {e}")
                    break
        threading.Thread(target=receive_messages, daemon=True).start()
        # Comandi utente
        while True:
            cmd = input("Comando (chat, upload, download, exit): ").strip().lower()
            if cmd == "chat":
                message = input("Messaggio: ")
                client_sock.send(f"CHAT:{message}".encode())
            elif cmd == "upload":
                file_path = select_file(False, "Percorso file: ")  # Forzato testuale per semplicità
                if os.path.isfile(file_path):
                    encrypted_path = encrypt_file(file_path, room_key)
                    with open(encrypted_path, "rb") as f:
                        file_data = f.read()
                    filename = os.path.basename(file_path)
                    client_sock.send(f"UPLOAD:{filename}:{len(file_data)}".encode())
                    client_sock.send(file_data)
                    os.remove(encrypted_path)
                else:
                    print("File non trovato")
            elif cmd == "download":
                filename = input("Nome file: ")
                client_sock.send(f"DOWNLOAD:{filename}".encode())
                data = client_sock.recv(1024 * 1024)  # Aumentato buffer per file più grandi
                if data == b"FILE_NOT_FOUND":
                    print("File non trovato")
                else:
                    encrypted_path = os.path.join(temp_dir, filename + ".lock")
                    with open(encrypted_path, "wb") as f:
                        f.write(data)
                    decrypted_path = decrypt_file(encrypted_path, room_key)
                    if decrypted_path:
                        print(f"File scaricato e decrittografato in {decrypted_path}")
                    else:
                        print("Decrittografia fallita")
            elif cmd == "exit":
                break
            else:
                print("Comando non riconosciuto")
        client_sock.close()

# **Funzione principale**
def main():
    bootloader()
    secure_login()
    use_graphical = input("Usare interfaccia grafica? (s/n): ").strip().lower() == "s"
    while True:
        print("1. Apri file manager")
        print("2. Crittografa file")
        print("3. Decrittografa file")
        print("4. Accedi a stanza di rete")
        print("5. Crea stanza di rete")
        print("6. Esci")
        choice = input("Scelta: ").strip()
        if choice == "1":
            if use_graphical:
                open_file_explorer(temp_dir)
            else:
                text_file_manager(temp_dir)
        elif choice == "2":
            file_path = select_file(use_graphical, "File da crittografare: ")
            if os.path.isfile(file_path):
                new_path = encrypt_file(file_path, user_key)
                print(f"Criptato in {new_path}")
            else:
                print("File non trovato")
        elif choice == "3":
            file_path = select_file(use_graphical, "File da decrittografare: ")
            if os.path.isfile(file_path) and file_path.endswith(".lock"):
                new_path = decrypt_file(file_path, user_key)
                if new_path:
                    print(f"Decrittografato in {new_path}")
                else:
                    print("Decrittografia fallita")
            else:
                print("File non trovato o non criptato")
        elif choice == "4":
            access_room()
        elif choice == "5":
            create_room()
        elif choice == "6":
            break
        else:
            print("Scelta non valida")

if __name__ == "__main__":
    main()