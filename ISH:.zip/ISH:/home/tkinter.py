import sys

# Simulazione della classe principale di Tkinter
class Tk:
    def __init__(self):
        print("[INFO] Tkinter GUI disabilitata (emulazione).")

    def mainloop(self):
        print("[INFO] Mainloop ignorato.")

    def withdraw(self):
        print("[INFO] Chiamata a withdraw ignorata.")

    def destroy(self):
        print("[INFO] Chiamata a destroy ignorata.")

# Simulazione dei widget di Tkinter
class Widget:
    def __init__(self, *args, **kwargs):
        pass

    def pack(self, *args, **kwargs):
        pass

    def grid(self, *args, **kwargs):
        pass

    def place(self, *args, **kwargs):
        pass

    def destroy(self):
        pass

class Label(Widget):
    def __init__(self, *args, **kwargs):
        pass

class Button(Widget):
    def __init__(self, *args, **kwargs):
        pass

class Entry(Widget):
    def __init__(self, *args, **kwargs):
        self.text = ""

    def get(self):
        return self.text

    def insert(self, index, value):
        self.text = value

    def delete(self, start, end=None):
        self.text = ""

class Frame(Widget):
    def __init__(self, *args, **kwargs):
        pass

class Canvas(Widget):
    def __init__(self, *args, **kwargs):
        pass

# Simulazione della gestione delle finestre di dialogo
class messagebox:
    @staticmethod
    def showinfo(title, message):
        print(f"[INFO] {title}: {message}")

    @staticmethod
    def showwarning(title, message):
        print(f"[WARNING] {title}: {message}")

    @staticmethod
    def showerror(title, message):
        print(f"[ERROR] {title}: {message}")

    @staticmethod
    def askyesno(title, message):
        print(f"[QUESTION] {title}: {message} (Risposta simulata: No)")
        return False

    @staticmethod
    def askokcancel(title, message):
        print(f"[QUESTION] {title}: {message} (Risposta simulata: OK)")
        return True

# Simulazione delle finestre di dialogo semplici
class simpledialog:
    @staticmethod
    def askstring(title, prompt):
        print(f"[INPUT] {title}: {prompt} (Risposta simulata: '')")
        return ""

    @staticmethod
    def askinteger(title, prompt):
        print(f"[INPUT] {title}: {prompt} (Risposta simulata: 0)")
        return 0

    @staticmethod
    def askfloat(title, prompt):
        print(f"[INPUT] {title}: {prompt} (Risposta simulata: 0.0)")
        return 0.0

# Simulazione delle funzionalità di ttk
class ttk:
    class Widget(Widget):
        pass

    class Label(Label):
        pass

    class Button(Button):
        pass

    class Entry(Entry):
        pass

    class Frame(Frame):
        pass

    class Combobox(Widget):
        def __init__(self, *args, **kwargs):
            self.values = []
            self.current_index = 0

        def set(self, value):
            print(f"[INFO] Combobox impostata a: {value}")

        def get(self):
            return ""

        def configure(self, *args, **kwargs):
            pass

        def bind(self, *args, **kwargs):
            pass

    class Treeview(Widget):
        def __init__(self, *args, **kwargs):
            self.items = {}

        def insert(self, parent, index, iid=None, values=()):
            self.items[iid] = values

        def delete(self, iid):
            if iid in self.items:
                del self.items[iid]

        def item(self, iid, option=None, **kwargs):
            if option == "values":
                return self.items.get(iid, ())
            return {}

# Alias per compatibilità con "import tkinter as tk"
sys.modules["tkinter.messagebox"] = messagebox
sys.modules["tkinter.ttk"] = ttk
sys.modules["tkinter.simpledialog"] = simpledialog